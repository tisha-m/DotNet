﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Employee
    {
        private int eId;
        private string name;
        private double basicsalary;
        private double netsalary;

        public Employee(int eId, string name, double salary)
        {
            eId = eId;
            name = name;
            basicsalary  = salary;
        }

        public void CalculateSalary()
        {
            double hra = basicsalary * 0.20;
            double da = basicsalary * 0.10;

            netsalary = basicsalary + hra + da;
        }

        public void Display()
        {
            Console.WriteLine("-------Employee Details-------");
            Console.WriteLine("Employee ID:" + eId);
            Console.WriteLine("Employee Name:" + name);
            Console.WriteLine("Employee Basic Salary:" + basicsalary);
            Console.WriteLine("Employee Net Salary:" + netsalary);
        }
    }

    class P10
    {
        public static void P10Main(string[] args)
        {
            Console.Write("Enter Employee ID: ");
            int eId = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Basic Salary: ");
            double salary = Convert.ToDouble(Console.ReadLine());

            Employee emp = new Employee(eId, name, salary);

            emp.CalculateSalary();
            emp.Display();

            Console.ReadLine();
        }
    }


}
