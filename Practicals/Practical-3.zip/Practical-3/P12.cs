﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student12
    {
        public int enrollno { get; set; }

        public string name { get; set; }
    }

    class P12
    {
        public static void P12Main(string[] args)
        {
            Student12 student = new Student12();
            Console.Write("Enter Enrollment Number: ");
            student.enrollno = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Name: ");
            student.name = Console.ReadLine();

            Console.WriteLine("-----Student Details-----");
            Console.WriteLine("Enrollment Number: " + student.enrollno);
            Console.WriteLine("Name: " + student.name);
            Console.ReadLine();
        }
    }
}
