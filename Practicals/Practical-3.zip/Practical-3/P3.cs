﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Students
    {
        public int id;
        public string name;

        public int Id
        {
            get { return id; }    //get read the value
            set { id = value; }   //set write the value
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Students()
        { 
            id = 0;
            name = "Unknown";
        }

        public Students(int id, string name)
        {
            this.id = id;
            this.name = name;
        }

        public void Display()
        {
            Console.WriteLine("Student ID: " + id);
            Console.WriteLine("Student Name: " + name);
        }

    }

    class P3
    {
        public static void P3Main(string[] args)
        {
            Console.WriteLine("Enter Student ID: ");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Student Name: ");
            string name = Console.ReadLine();

            Students student = new Students(id, name);
            Console.WriteLine("Student Details:");
            Console.WriteLine("ID: " + student.Id);
            Console.WriteLine("Name: " + student.Name);

            Console.ReadLine();
        }
    }
}
