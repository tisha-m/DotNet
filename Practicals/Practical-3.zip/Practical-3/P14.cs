﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Employees
    {
        private double salary;

        public void SetSalary(double amount)
        {
            if (amount > 0) 
            {
                salary = amount;
            }
            else
            {
                Console.WriteLine("Invalid Salary!!!");
            }
        }

        public double GetSalary()
        {
            return salary;
        }
    }

    class P14
    {
        public static void P14Main(string[] args)
        {
            Employees emp = new Employees();

            Console.Write("Enter Salary: ");
            double amount = Convert.ToDouble(Console.ReadLine());

            emp.SetSalary(amount);

            Console.WriteLine("Employee's Salary: " + emp.GetSalary());

            Console.ReadLine();
        }
    }
}
