﻿using Practical_3;
using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Employe
    {
        public int EmployeeId { get; set; }

        public string Name { get; set; }

        public double BasicSalary { get; set; }
    }

    //Derived class for Employe2
    class PeremanentEmploye : Employe
    {
        public void CalculateSalary()
        {
            double HRA = BasicSalary * 0.20;
            double DA = BasicSalary * 0.10;
            double NetSalary = BasicSalary + HRA + DA;

            Console.WriteLine("-----Employee Details-----");
            Console.WriteLine("Employee ID: " + EmployeeId);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Basic Salary: " + BasicSalary);
            Console.WriteLine("HRA: " + HRA);
            Console.WriteLine("DA: " + DA);
            Console.WriteLine("Net Salary: " + NetSalary);
        }
    }

    class ContractEmployee : Employe
    {
        public void CalculateSalary()
        {
            Console.WriteLine("-----Contract Employee Details-----");
            Console.WriteLine("Employee ID: " + EmployeeId);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Basic Salary: " + BasicSalary);
        }
    }

    class P16
    {
        public static void P16Main(string[] args)
        {
            PeremanentEmploye p = new PeremanentEmploye();
            p.EmployeeId = 101;
            p.Name = "Darsh";
            p.BasicSalary = 20000;

            p.CalculateSalary();

            ContractEmployee c = new ContractEmployee();
            c.EmployeeId = 101;
            c.Name = "Darsh";
            c.BasicSalary = 20000;

            c.CalculateSalary();

            Console.ReadLine();
        }
    }
}


//Console.Write("Enter Employee ID: ");
//int employeeId = Convert.ToInt32(Console.ReadLine());

//Console.Write("Enter Name: ");
//string name = Console.ReadLine();

//Console.Write("Enter Basic Salary: ");
//double basicSalary = Convert.ToDouble(Console.ReadLine());

//Console.Write("Is the employee permanent? (yes/no): ");
//string isPermanent = Console.ReadLine();

//if (isPermanent.ToLower() == "yes")
//{
//    PeremanentEmploye permanentEmployee = new PeremanentEmploye
//    {
//        EmployeeId = employeeId,
//        Name = name,
//        BasicSalary = basicSalary
//    };
//    permanentEmployee.CalculateSalary();
//}
//else
//{
//    ContractEmployee contractEmployee = new ContractEmployee
//    {
//        EmployeeId = employeeId,
//        Name = name,
//        BasicSalary = basicSalary
//    };
//    contractEmployee.CalculateSalary();
//}
//Console.ReadLine();