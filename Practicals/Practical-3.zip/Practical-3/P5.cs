﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Product
    {
        int pcode;
        string pname, mname;

        public Product(int pcd, string pnm, string mnm)
        {
            pcode = pcd;
            pname = pnm;
            mname = mnm;
        }

        public void Display()
        {
            Console.WriteLine("Product Code:= " + pcode);
            Console.WriteLine("Product Name:= " + pname);
            Console.WriteLine("Manufacturer Name:= " + mname);
        }
    }

    public class P5
    {
        public static void P5Main(string[] args)
        {
            Console.WriteLine("Darshan Parmar-25SOECE13072");
            if (args.Length < 3)
            {
                Console.WriteLine("Syntax Error:Please provide the product code, product name, and manufacturer name");
                return;
            }
            int pcd = Convert.ToInt32(args[0]);
            string pnm = args[1];
            string mnm = args[2];

            Product p = new Product(pcd, pnm, mnm);

            p.Display();

            Console.Read();
        }
    }
}


//Execute the program with the following command line arguments:P5.exe 101 "Darshan" "Parmar"