﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student19
    {
        //Static keyword shared to all objects,belongs to class.
        static int count = 0;

        //Constructor
        public Student19()
        {
            count++;
        }

        public static void DisplayCount()
        {
            Console.WriteLine("Number of Student:" + count);
        }
    }

    class P19
    {
        public static void P19Main(string[] args)
        {
            Student19 s1 = new Student19();
            Student19 s2 = new Student19();
            Student19 s3 = new Student19();

            Student19.DisplayCount();
            Console.ReadLine();
        }
    }
}
