﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class ProductDetails
    {
        public int proId { get; set; }
        public string Name { get; set; }
        public double price { get; set; }
        public int quantity { get; set; }

        public double CalculateBill()
        {
            return price * quantity;
        }

        public void Display()
        {
            Console.WriteLine("-------Product Details-------");
            Console.WriteLine("Product ID: " + proId);
            Console.WriteLine("Product Name: " + Name);
            Console.WriteLine("Product Price: " + price);
            Console.WriteLine("Product Quantity: " + quantity);
            Console.WriteLine("Total Bill Amount: " + CalculateBill());
        }
    }

    class P13
    {
        public static void P13Main(string[] args)
        {
            ProductDetails product = new ProductDetails();

            Console.Write("Enter Product ID: ");
            product.proId = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Product Name: ");
            product.Name = Console.ReadLine();

            Console.Write("Enter Product Price: ");
            product.price = Convert.ToDouble(Console.ReadLine());
            
            Console.Write("Enter Product Quantity: ");
            product.quantity = Convert.ToInt32(Console.ReadLine());

            product.Display();
            Console.ReadLine();
        }
    }
}
