﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    // Base class
    class Employee18
    {
        public string Name { get; set; }
        public double BasicSalary { get; set; }

        // Virtual method to generate salary slip
        public virtual void GenerateSalarySlip()
        {           
            Console.WriteLine("Employee Salary Slip");
            Console.WriteLine("Name : " + Name);
            Console.WriteLine("Basic Salary :" + BasicSalary);
            Console.WriteLine("Total Salary :" + BasicSalary);
        }
    }

    // Permanent Employee - gets HRA + DA
    class PermanentEmployee : Employee18
    {
        // Override GenerateSalarySlip method
        public override void GenerateSalarySlip()
        {
            double HRA = BasicSalary * 0.20;  // 20% HRA
            double DA = BasicSalary * 0.10;   // 10% DA
            double NetSalary = BasicSalary + HRA + DA;

            Console.WriteLine("Permenent Employee Salary Slip");
            Console.WriteLine("Name :" + Name);
            Console.WriteLine("Basic Salary :" + BasicSalary);
            Console.WriteLine("HRA :" + HRA);
            Console.WriteLine("DA :" + DA);
            Console.WriteLine("NET SALARY :" + NetSalary);
        }
    }

    // Contract Employee - gets only basic salary with GST deduction
    class ContractEmploye : Employee18
    {
        // Override GenerateSalarySlip method
        public override void GenerateSalarySlip()
        { 
            Console.WriteLine("Contract Emplopyee Salary Slip");
            Console.WriteLine("Name : " + Name);
            Console.WriteLine("Salary :" + BasicSalary);
        }
    }

    // Main class
    class P18
    {
        public static void P18Main(string[] args)
        {

            // Permanent Employee
            PermanentEmployee p = new PermanentEmployee();
            p.Name = "Darsh";
            p.BasicSalary = 20000;
            p.GenerateSalarySlip();

            // Contract Employee
            ContractEmploye c = new ContractEmploye();
            c.Name = "Darshan";
            c.BasicSalary = 20000;
            c.GenerateSalarySlip();

            Console.ReadLine();
        }
    }
}
