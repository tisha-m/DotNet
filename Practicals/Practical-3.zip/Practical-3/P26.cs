﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Practical_3
{
    class P26
    {
        public static void P26Main(string[] args)
        {
            Console.Write("Enter Cutomer Name: ");
            string name = Console.ReadLine();

            Console.WriteLine("String Operations:");

            name = name.Trim();

            Console.WriteLine("After Trim: " + name);

            Console.WriteLine("Uppercase Name: " + name.ToUpper());

            Console.WriteLine("Lowercase Name: " + name.ToLower());

            string replacedName = name.Replace(' ', '_');

            Console.WriteLine("After Replacing: " + replacedName);

            string formattedName = name.Insert(0, "Mr. ");

            Console.WriteLine("After Insert:" + formattedName);

            Console.WriteLine("Length of Name: " + name.Length);

            Console.ReadLine();
        }
    }
}
