﻿using System;
using System.Collections.Generic;
using System.Runtime.Intrinsics.Arm;
using System.Text;

namespace Practical_3
{
    //BASE CLASS
    class Shape
    {   
        private double area;

        //Virtual method to calculate area
        public virtual void CalculateArea()
        {
            Console.WriteLine("Calculating area of shape");
        }
    }

    //DERIVED CLASS
    class Circle : Shape 
    {
        //override keyword in derived class is to change the method's behaviour
        public override void CalculateArea()
        {
            double radius = 5;
            double area = 3.14 * radius * radius;
            Console.WriteLine("Area of Circle: " + area);
        }
    }

    //DERIVED CLASS
    class Rectangle : Shape
    {
        public override void CalculateArea()
        {
            double length = 10;
            double breadth = 5;
            double area = length * breadth;
            Console.WriteLine("Area of Rectangle: " + area);
        }
    }

    //DERIVED CLASS
    class Triangle : Shape
    {
        public override void CalculateArea()
        {
            double baseLength = 10;
            double height = 5;
            double area = 0.5 * baseLength * height;
            Console.WriteLine("Area of Triangle: " + area);
        }
    }

    class P17
    {
        public static void P17Main(string[] args)
        {
            Shape c = new Circle();
            c.CalculateArea();

            Shape r = new Rectangle();
            r.CalculateArea();

            Shape t = new Triangle();
            t.CalculateArea();

            Console.ReadLine();
        }
    }
}
