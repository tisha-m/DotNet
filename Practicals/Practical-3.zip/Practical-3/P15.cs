﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    //Base Class
    class Student15
    {
        public string Cource { get; set; }
        public string Department { get; set; }

        public void DisplayStudent()
        {
            Console.WriteLine("-----Student Details-----");
            Console.WriteLine("Course: " + Cource);
            Console.WriteLine("Department: " + Department);
        }
    }

    //Derived Class
    class Person : Student15
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public void DisplayPerson()
        {
            Console.WriteLine("-----Person Details-----");
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Age: " + Age);
        }
    }

    class P15
    {
        public static void P15Main(string[] args)
        {
            Person person = new Person();

            Console.Write("Enter Name: ");
            person.Name = Console.ReadLine();

            Console.Write("Enter Age: ");
            person.Age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Course: ");
            person.Cource = Console.ReadLine();

            Console.Write("Enter Department: ");
            person.Department = Console.ReadLine();

            person.DisplayPerson();
            person.DisplayStudent();

            Console.ReadLine();
        }
    }
}
