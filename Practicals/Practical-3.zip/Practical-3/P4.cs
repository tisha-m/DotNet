﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Students4
    {
        public int id;
        public string name;

        public int Id
        {
            get { return id; }    //get read the value
            set { id = value; }   //set write the value
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Students4()
        {
            id = 0;
            name = "Unknown";
        }

        public Students4(int id, string name)
        {
            this.id = id;
            this.name = name;
        }

        public void Display()
        {
            Console.WriteLine("Student ID: " + id);
            Console.WriteLine("Student Name: " + name);
        }

    }

    class P4
    {
        public static void P4Main(string[] args)
        {
            Students4 s1 = new Students4(101,"Darshan");
            s1.Display();

            Students4 s2 = new Students4(102, "Darsh");
            s2.Display();

            Students4 s3 = new Students4(103, "DP");
            s3.Display();

            Students4 s4 = new Students4(104, "D");
            s4.Display();

            Students4 s5 = new Students4(105, "DK");
            s5.Display();

            Console.ReadLine();
        }
    }
}
