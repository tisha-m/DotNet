﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class BankAccounts
    {
        private int accountNumber;
        private string accountHolderName;
        private double balance;
        public BankAccounts(int accountNumber, string accountHolderName, double balance)
        {
            this.accountNumber = accountNumber;
            this.accountHolderName = accountHolderName;
            this.balance = balance;
        }
        public void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Deposited Amount: " + amount);
        }
        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine("Withdrawn Amount: " + amount);
            }
            else
            {
                Console.WriteLine("Insufficient balance.");
            }
        }
        public void Display()
        {
            Console.WriteLine("-------Bank Account Details-------");
            Console.WriteLine("Account Number: " + accountNumber);
            Console.WriteLine("Account Holder Name: " + accountHolderName);
            Console.WriteLine("Balance: " + balance);
        }
    }

    class P11
    {
        public static void P11Main(string[] args)
        {
            Console.Write("Enter Account Number: ");
            int accountNumber = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Account Holder Name: ");
            string accountHolderName = Console.ReadLine();

            Console.Write("Enter Initial Balance: ");
            double balance = Convert.ToDouble(Console.ReadLine());

            BankAccounts account = new BankAccounts(accountNumber, accountHolderName, balance);

            Console.Write("Enter amount to deposit: ");
            double depositAmount = Convert.ToDouble(Console.ReadLine());
            account.Deposit(depositAmount);

            Console.Write("Enter amount to withdraw: ");
            double withdrawAmount = Convert.ToDouble(Console.ReadLine());
            account.Withdraw(withdrawAmount);

            account.Display();
            Console.ReadLine();
        }
    }
}
