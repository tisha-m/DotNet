﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student
    {
        private int rno;
        private string name;
        private string branch;


        public Student(int rno, string name, string branch)
        {
            this.rno = rno;
            this.name = name;
            this.branch = branch;
        }

        public void Display()
        {
            Console.WriteLine("----------Student Details----------");
            Console.WriteLine("Roll Number: " + rno);
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Branch " + branch);
        }
    }

    class P1
    {
        public static void P1Main(string[] args)
        {
              Console.WriteLine("Enter Roll Number: ");
            int rno = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Branch: ");
            string branch = Console.ReadLine();

            Student obj = new Student(rno, name, branch);
            obj.Display();

            Console.ReadLine();

        }
    }
}

