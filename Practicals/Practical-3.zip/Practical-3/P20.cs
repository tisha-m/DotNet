﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student20
    {
        private int roll_no;
        private string name;

        public Student20(int roll_no, string name)
        {
            this.roll_no = roll_no;
            this.name = name;
        }

        public void DisplayDetails()
        {
            Console.WriteLine("Roll No: " + roll_no);
            Console.WriteLine("Name: " + name);
        }
    }

    class P20
    {
        public static void P20Main(string[] args)
        {
            Student20 s1 = new Student20(101, "Darsh");
            Student20 s2 = new Student20(102, "Darshan");
            s1.DisplayDetails();
            Console.WriteLine();
            s2.DisplayDetails();
            Console.ReadLine();
        }
    }
}
