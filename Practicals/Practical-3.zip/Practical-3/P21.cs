﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    //BASE CLASS
    class Student21
    {
        protected int roll_no;
        protected string name;

        public Student21(int roll_no, string name)
        {
            this.roll_no = roll_no;
            this.name = name;
        }
    }

    //DERIVED CLASS
    class StudentDetails : Student21
    {
        private string course;
        private int year;
        public StudentDetails(int roll_no, string name, string course, int year) : base(roll_no, name)
        {
            this.course = course;
            this.year = year;
        }
        public void DisplayDetails()
        {
            Console.WriteLine("Roll No: " + roll_no);
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Course: " + course);
            Console.WriteLine("Year: " + year);
        }
    }

    class P21
    {
        public static void P21Main(string[] args)
        {
            StudentDetails s1 = new StudentDetails(101, "Darsh", "B.Tech", 2);
            s1.DisplayDetails();
            Console.ReadLine();
        }
    }
}