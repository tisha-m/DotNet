﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Practical_3
{
    class Clock9
    {
        private int hours;
        private int minutes;
        private int seconds;


        public Clock9()
        {
            DateTime now = DateTime.Now;

            hours = now.Hour;
            minutes = now.Minute;
            seconds = now.Second;
        }


        public void DisplayTime()
        {
            Console.WriteLine("Current Time: {0:D2}:{1:D2}:{2:D2}",
                hours, minutes, seconds);
        }


        public void IncrementSecond()
        {
            seconds++;

            if (seconds >= 60)
            {
                seconds = 0;
                minutes++;

                if (minutes >= 60)
                {
                    minutes = 0;
                    hours++;

                    if (hours >= 24)
                    {
                        hours = 0;
                    }
                }
            }
        }
    }

    class P9
    {
        public static void P9Main(string[] args)
        {

            Clock9 clock = new Clock9();


            clock.DisplayTime();


            clock.IncrementSecond();

            Console.WriteLine("After 1 Second:");
            clock.DisplayTime();

            Console.ReadLine();
        }
    }
}
