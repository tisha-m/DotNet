﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    //BASE CLASS
    class Student22
    {
        private string course;

        public void DisplayDetails()
        {
            Console.WriteLine("My Course is BTech-CE");
        }
    }

    //DERIVED CLASS
    class Stu : Student22
    {
        public new void DisplayDetails()
        {
            Console.WriteLine("My Course is MTech-CE");
        }
    }

    class P22
    {
        public static void P22Main(string[] args)
        {
            Stu s1 = new Stu();
            s1.DisplayDetails(); // Calls the derived class method
        }
    }
}