﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student8
    {
        private int rollNo;
        private string name;
        private string course;
       

        public Student8()
        {
            Console.WriteLine("Enter Student Details");
        }

        public void AcceptDetails()
        {
            Console.Write("Enter Roll No: ");
            rollNo = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Name: ");
            name = Console.ReadLine();

            Console.Write("Enter Course: ");
            course = Console.ReadLine();

        }

        public void DisplayDetails()
        {
            Console.WriteLine("--- Student Details ---");
            Console.WriteLine("Roll No: " + rollNo);
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Course: " + course);
           
        }
    }

    class P8
    {
        public static void P8Main(string[] args)
        {            
            Student8 student = new Student8();

            student.AcceptDetails();
            student.DisplayDetails();

            Console.ReadLine();
        }
    }
}

