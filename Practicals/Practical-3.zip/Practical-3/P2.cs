﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace Practical_3
{
    class Clock
    {
        //Private data members
        private int hour;
        private int min;
        private int sec;

        //No Arguments constructor
        public Clock()  
        {
            hour = 12;
            min = 0;
            sec = 0;
        }

        //Three Arguments constructor
        public Clock(int hour, int min, int sec)
        {
            hour = hour;
            min = min;
            sec = sec;
        }

        //Increment time method
        public void IncrementTime()
        {
            sec++;
            if (sec >= 60)
            {
                sec = 0;
                min++;
                if (min >= 60)
                {
                    min = 0;
                    hour++;
                    if (hour >= 24)
                    {
                        hour = 0;
                    }
                }
            }
        }

        //Display time method
        public void DisplayTime()
        {
            Console.WriteLine("Time: {0:D2}:{1:D2}:{2:D2}", hour, min, sec);
        }

        public int GetHour()
        {
            return hour;
        }

        public int GetMinute()
        {
            return min;
        }

        public int GetSeconds()
        {
            return sec;
        }
    }

    class P2
    {
        public static void P2Main(string[] args)
        {
            Clock clock = new Clock();
            clock.DisplayTime();

            Console.WriteLine("Incrementing time by 1 second...");
            clock.IncrementTime();
            clock.DisplayTime();

            Console.WriteLine("Incrementing time by 1 second...");
            clock.IncrementTime();
            clock.DisplayTime();

            Console.WriteLine("Incrementing time by 1 second...");
            clock.IncrementTime();
            clock.DisplayTime();

            Console.WriteLine("Incrementing time by 1 second...");
            clock.IncrementTime();
            clock.DisplayTime();

            Console.WriteLine("Hour: " + clock.GetHour());
            Console.WriteLine("Min: " + clock.GetMinute());
            Console.WriteLine("Sec: " + clock.GetSeconds());
            
            Console.ReadLine();
        }
    }
}