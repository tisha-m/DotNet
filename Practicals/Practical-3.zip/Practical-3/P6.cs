﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3

{

    class Line

    {

        private double length; 

        public Line()

        {
            Console.WriteLine("Object creating value of length = 10");
            length = 10;
        }

        public void setLength(double len)

        {
            length = len;
        }

        public double getLength()

        {
           return length;
        }

    }

    class P6

    {

        public static void P6Main(string[] args)

        {

            Line line = new Line();

            Console.WriteLine("Length of line : {0}", line.getLength());

            line.setLength(6);

            Console.WriteLine("Length of line : {0}", line.getLength());

            Console.ReadKey();

        }

    }

}