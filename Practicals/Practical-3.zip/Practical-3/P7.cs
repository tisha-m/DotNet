﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Practical_3
{
    class Student7
    {
        private int enroll;
        private string name;

        public Student7(int enroll, string name)
        {
            this.enroll = enroll;
            this.name = name;
        }

        public void Display()
        {
            Console.WriteLine("Enrollment Number: " + enroll);
            Console.WriteLine("Student Name: " + name);
        }
    }

    class P7
    {
        public static void P7Main(string[] args)
        {
            Console.WriteLine("Enter Enrollment Number:");
            int enroll = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Student Name:");
            string name = Console.ReadLine();

            Student7 s1 = new Student7(enroll,name);
            s1.Display();
            Console.ReadLine();
        }
    }
}
