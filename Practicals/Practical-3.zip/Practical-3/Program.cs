﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Darshan Parmar-25SOECE13072");
            //P1.P1Main(args);
            //P2.P2Main(args);
            //P3.P3Main(args);
            //P4.P4Main(args);
            //P5.P5Main(args);
            //P6.P6Main(args);
            //P7.P7Main(args);
            //P8.P8Main(args);
            //P9.P9Main(args);
            //P10.P10Main(args);
            //P11.P11Main(args);
            //P12.P12Main(args);
            //P13.P13Main(args);
            //P14.P14Main(args);
            //P15.P15Main(args);
            //P16.P16Main(args);
            //P17.P17Main(args);
            //P18.P18Main(args);
            //P19.P19Main(args);
            //P20.P20Main(args);
            //P21.P21Main(args);
            //P22.P22Main(args);
            //P23.P23Main(args);
            //P24.P24Main(args);
            //P25.P25Main(args);
            P26.P26Main(args);
        }
    }
}